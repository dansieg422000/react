const post = {
  id: 1,
  summary:
    "Excited to be in Melbourne mentoring smart folks from Indonesia & Australia...  looking at how best to link our startup ecosystems!",
  img: "",
  likes: 12,
  user: {
    id: "sina",
    name: "Sina",
    email: "sina@gmail.com",
    img: "static/profile/g.gif"
  }
};

export default post;
