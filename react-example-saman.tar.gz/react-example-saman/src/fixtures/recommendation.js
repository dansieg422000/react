const recommendation = {
  id: 1,
  user: {
    id: "verica",
    name: "Verica",
    email: "verica@gmail.com",
    img: "static/profile/a.gif"
  },
  summary:
    "Rachel was an exceptional and vital member of our team at CORESTAFF. She is highly skilled at working with mid to senior level management and has a talent for finding qualified candidates to fill any role. I really enjoyed working with Rachel and admire her for her dedication and adaptability."
};

export default recommendation;
