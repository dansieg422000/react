const experience = {
  id: 1,
  title: "Recruiter",
  summary:
    "Aramco Services Company (ASC) is the U.S.-based subsidiary of Saudi Aramco, the state-owned oil company of the Kingdom of Saudi Arabia and a fully integrated, global petroleum and chemicals enterprise. ASC’s geographical area of responsibility extends throughout North America, with operations in the U.S. and Canada, and selected activities in South America.",
  date: "Jan 2014 - Present"
};

export default experience;
