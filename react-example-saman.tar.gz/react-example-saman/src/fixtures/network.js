const network = [
  {
    id: "saman",
    name: "Saman",
    email: "samanshafigh@gmail.com",
    img: "static/profile/g.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "sina",
    name: "Sina",
    email: "sina@gmail.com",
    img: "static/profile/a.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "kyoshi",
    name: "Kyoshi",
    email: "kyoshi@gmail.com",
    img: "static/profile/k.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "omar",
    name: "Omar",
    email: "omar@gmail.com",
    img: "static/profile/b.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "jinora",
    name: "Jinora",
    email: "Jinora@gmail.com",
    img: "static/profile/l.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "verica",
    name: "Verica",
    email: "verica@gmail.com",
    img: "static/profile/c.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "dave",
    name: "Dave",
    email: "dave@gmail.com",
    img: "static/profile/d.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "shayan",
    name: "Shayan",
    email: "shayan@gmail.com",
    img: "static/profile/e.gif",
    location: "Sydney, Australia",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "faraz",
    name: "Faraz",
    email: "faraz@gmail.com",
    img: "static/profile/f.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "momo",
    name: "Momo",
    email: "momo@gmail.com",
    img: "static/profile/m.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "ronak",
    name: "Ronak",
    email: "ronak@gmail.com",
    img: "static/profile/h.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "ronak",
    name: "Ronak",
    email: "ronak@gmail.com",
    img: "static/profile/h.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "chao",
    name: "Chao",
    email: "chao@gmail.com",
    img: "static/profile/i.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  },
  {
    id: "asha",
    name: "Asha",
    email: "chao@gmail.com",
    img: "static/profile/j.gif",
    location: "Sydney, Australia",
    occupation: "Software Development",
    connection: 500,
    summary:
      "I have worked in the recruitment industry for 10 years, ultimately gaining experience in B2B sales, talent marketing, human resources practices, sourcing and recruiting at a variety of levels. As a recruiter, I take pride in ensuring that placements are a strong match for all parties."
  }
];

export default network;
