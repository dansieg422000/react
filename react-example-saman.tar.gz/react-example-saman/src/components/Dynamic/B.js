import React from "react";

const B = ({ children }) => {
  return <div>{children}</div>;
};

export default B;
