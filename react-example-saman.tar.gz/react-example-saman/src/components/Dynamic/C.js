import React from "react";

const C = ({ children }) => {
  return <div>{children}</div>;
};

export default C;
