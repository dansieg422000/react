export default [
  {
    name: "A",
    path: "./components/Dynamic/A"
  },
  {
    name: "B",
    path: "./components/Dynamic/B"
  },
  {
    name: "C",
    path: "./components/Dynamic/C"
  }
];
