import { css } from "glamor";

export const getConnectionStyle = () => {
  return css({
    paddingLeft: "4px"
  });
};
