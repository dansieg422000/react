import * as icons from "react-icons-kit/md";

export default icons;
